class APIservice {
  static const address = "https://msltech.ai/laundry/apis";
  //static const address = "http://192.168.1.8:8081";
}
