import 'package:flutter/material.dart';
import 'package:laundry_application/Screens/AboutScreen.dart';
import 'package:laundry_application/Screens/PrivacyPolicyScreen.dart';
import 'package:laundry_application/Screens/ProfileUpdateScreen.dart';
import 'package:laundry_application/Screens/ResetPasswordScreen.dart';
import 'package:laundry_application/Screens/TermsOfServiceScreen.dart';
import 'package:laundry_application/providers/ThemeProvider.dart';
import 'package:provider/provider.dart';

class SettingsScreen extends StatefulWidget {
  SettingsScreen({super.key});

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsScreen> {
  bool _notificationsEnabled = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Settings',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.blueAccent,
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: <Widget>[
          ListTile(
            title: Text(
              'Profile',
              style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
            ),
            trailing: Icon(Icons.arrow_forward_ios,
                color: Colors.blueAccent, size: 16),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileUpdateScreen()),
              );
            },
          ),
          Divider(),
          SwitchListTile(
            title: Text(
              'Notifications',
              style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
            ),
            value: _notificationsEnabled,
            activeColor: Colors.blueAccent,
            onChanged: (bool value) {
              setState(() {
                _notificationsEnabled = value;
              });
            },
          ),
          Divider(),
          SwitchListTile(
            title: Text(
              'Dark Mode',
              style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
            ),
            value: context.watch<ThemeProvider>().isDarkMode,
            activeColor: Colors.blueAccent,
            onChanged: (bool value) {
              context.read<ThemeProvider>().toggleTheme(value);
            },
          ),
          Divider(),
          ListTile(
            title: Text(
              'Reset Password',
              style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
            ),
            leading: Icon(Icons.lock_reset, color: Colors.blueAccent, size: 20),
            trailing: Icon(Icons.arrow_forward_ios,
                color: Colors.blueAccent, size: 16),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ResetPasswordScreen()),
              );
            },
          ),
          Divider(),
          ListTile(
            title: Text(
              'About',
              style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
            ),
            leading: Icon(Icons.info, color: Colors.blueAccent, size: 20),
            trailing: Icon(Icons.arrow_forward_ios,
                color: Colors.blueAccent, size: 16),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AboutScreen()),
              );
            },
          ),
          Divider(),
          ListTile(
            title: Text(
              'Privacy Policy',
              style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
            ),
            leading: Icon(Icons.lock, color: Colors.blueAccent, size: 20),
            trailing: Icon(Icons.arrow_forward_ios,
                color: Colors.blueAccent, size: 16),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => PrivacyPolicyScreen()),
              );
            },
          ),
          Divider(),
          ListTile(
            title: Text(
              'Terms of Service',
              style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
            ),
            leading:
                Icon(Icons.description, color: Colors.blueAccent, size: 20),
            trailing: Icon(Icons.arrow_forward_ios,
                color: Colors.blueAccent, size: 16),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => TermsOfServiceScreen()),
              );
            },
          ),
        ],
      ),
    );
  }
}
