import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/widgets.dart';
import 'package:laundry_application/Components/Chat_box.dart';
import 'package:laundry_application/Components/CustomRefral.dart';
import 'package:laundry_application/Components/ServicecardSkeleton.dart';
import 'package:laundry_application/Models/AppBannerModel.dart';
import 'package:laundry_application/Models/service_model.dart';
import 'package:laundry_application/Screens/Booking_item_screen.dart';
import 'package:laundry_application/Screens/CouponScreen.dart';
import 'package:laundry_application/Screens/ExploreScreen.dart';
import 'package:laundry_application/Screens/LoginPageScreen.dart';
import 'package:laundry_application/api_services/Service_api.dart';
import 'package:laundry_application/api_services/global.dart';
import 'package:laundry_application/api_services/user_api.dart';

class Home_screen extends StatefulWidget {
  const Home_screen({Key? key}) : super(key: key);

  @override
  State<Home_screen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<Home_screen> {
  late List<Service> _services = [];
  late List<AppBanner> _appBanner = [];
  List<Map<String, String>> imageList = [];
  final CarouselController carouselController = CarouselController();
  int currentIndex = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchServices();
    _fetchBanner();
  }

  Future<void> _fetchServices() async {
    try {
      List<Service> services = await fetchData();
      setState(() {
        _services = services;
        _isLoading = false;
      });
    } catch (error) {
      print('Error fetching services: $error');
    }
  }

  Future<void> _fetchBanner() async {
    try {
      List<AppBanner> appBanner = await fetchBanner();
      setState(() {
        _appBanner = appBanner;
        imageList = _appBanner.map((banner) {
          return {
            "id": "${banner.id}",
            "image-path": '${APIservice.address}${banner.bannerImage}'
          };
        }).toList();
        //_isLoading = false;
      });
    } catch (error) {
      print('Error fetching services: $error');
    }
  }

  void _openChatBox() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return ChatBox();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Stack(
                children: [
                  InkWell(
                      onTap: () {},
                      child: CarouselSlider(
                        items: imageList.map((item) {
                          return Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              Container(
                                margin: EdgeInsets.symmetric(horizontal: 5.0),
                                height: double.infinity,
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  color: Colors.grey[200],
                                  borderRadius: BorderRadius.circular(20.0),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 1,
                                      blurRadius: 5,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: Image.network(
                                  item['image-path']!,
                                  fit: BoxFit.fill,
                                  width: double.infinity,
                                ),
                              ),
                            ],
                          );
                        }).toList(),
                        carouselController: carouselController,
                        options: CarouselOptions(
                          scrollPhysics: const BouncingScrollPhysics(),
                          autoPlay: true,
                          aspectRatio: 2,
                          viewportFraction: 1,
                          onPageChanged: (index, reason) {
                            setState(() {
                              currentIndex = index;
                            });
                          },
                        ),
                      )),
                  Positioned(
                    bottom: 10,
                    left: 0,
                    right: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: imageList.asMap().entries.map((entry) {
                        return GestureDetector(
                          onTap: () =>
                              carouselController.animateToPage(entry.key),
                          child: Container(
                            width: currentIndex == entry.key ? 12 : 7,
                            height: 7.0,
                            margin: const EdgeInsets.symmetric(horizontal: 3.0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: currentIndex == entry.key
                                  ? Colors.white
                                  : Colors.orange,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
            Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 16.0, right: 16),
                  child: ClipRRect(
                    borderRadius: BorderRadius.only(
                        // topLeft: Radius.elliptical(30, 10),
                        // topRight: Radius.elliptical(30, 10)
                        ),
                    child: Container(
                      width: double.infinity,
                      height: 60,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(255, 15, 65, 150)
                          // image: DecorationImage(
                          //   image: AssetImage('assets/images/background.jpeg'),
                          //   fit: BoxFit.cover,
                          // ),
                          ),
                      child: Center(
                        child: Text(
                          'Our Services',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            shadows: [
                              Shadow(
                                blurRadius: 10.0,
                                color: Colors.black,
                                offset: Offset(3.0, 3.0),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: _isLoading
                  ? GridView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: 6,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10,
                          mainAxisExtent: 100),
                      itemBuilder: (context, index) {
                        return ServiceCardSkeleton();
                      })
                  : GridView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: _services.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10,
                          mainAxisExtent: 100),
                      itemBuilder: (context, index) {
                        Service service = _services[index];
                        return GestureDetector(
                            onTap: () async {
                              var UserId = await user_api.fetchUserID();
                              print(UserId);
                              if (UserId == "0") {
                                showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return AlertDialog(
                                      title: Text("Login Required"),
                                      content: Text(
                                          "Please log in to use our services."),
                                      actions: <Widget>[
                                        TextButton(
                                          child: Text("Cancel"),
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                        ),
                                        TextButton(
                                          child: Text("Login"),
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    LoginPageScreen(),
                                              ),
                                            );
                                          },
                                        ),
                                      ],
                                    );
                                  },
                                );
                              } else {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => BookingItemScreen(
                                      serviceID: service.id,
                                      serviceName: service.serviceName,
                                    ),
                                  ),
                                );
                              }
                            },
                            child: Container(
                                height: 10,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        width: 1, color: Colors.grey.shade300),
                                    borderRadius: BorderRadius.circular(10)),
                                child: Column(children: [
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: ClipRRect(
                                        borderRadius: BorderRadius.vertical(
                                            top: Radius.circular(10)),
                                        child: SizedBox(
                                            height: 50,
                                            child: Image.network(
                                                "${APIservice.address}${service.serviceImage}"))),
                                  ),
                                  Expanded(
                                    child: Container(
                                      child: Column(
                                        children: [
                                          Text(
                                            service.serviceName,
                                            style: TextStyle(
                                                color: Colors.black87,
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          // Text(
                                          //   'From Rs. ${service.servicePrice} ',
                                          //   style: TextStyle(
                                          //       color: Colors.blueAccent,
                                          //       fontSize: 12,
                                          //       fontWeight: FontWeight.bold),
                                          // ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ])));
                      },
                    ),
            ),
            Row(children: [
              Padding(
                padding: const EdgeInsets.only(left: 8.0, top: 8, bottom: 8),
                child: ExploreCard(
                  title: 'Special Offer',
                  description: 'Get 50% off on your first order!',
                  imageUrl: 'assets/images/5discount.jpg',
                ),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => CouponScreen()));
                },
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  elevation: 1,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15.0),
                      color: Color.fromARGB(255, 15, 65, 150),
                    ),
                    width: 100, // Set a fixed width for better alignment
                    height: 150,
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'See All',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 10),
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 30,
                          color: Colors.white,
                        ),
                      ],
                    ),
                  ),
                ),
              )
            ]),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child:
                    // CustomRefral(
                    //   title: "Refer a friend",
                    //   subtitle: "Get 10% off on your next order",
                    //   Subtitle1: "🎉 Claim now 🎉",
                    //   image: "assets/images/refer.jpg",
                    // ),
                    Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  elevation: 5,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.0),
                      gradient: LinearGradient(
                        colors: [
                          Color.fromARGB(255, 15, 65, 150),
                          Colors.white
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.group_add,
                                size: 30, color: Colors.white),
                            SizedBox(width: 10),
                            Text(
                              'Refer a Friend',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Text(
                          'Invite your friends and earn rewards!',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: Color.fromARGB(255, 15, 65, 150),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            elevation: 5,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 15.0, vertical: 10.0),
                            child: Text(
                              'Refer Now',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                )),
          ],
        ),
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: _openChatBox,
      //   child: Icon(Icons.message, color: Colors.white, size: 20),
      //   backgroundColor: Colors.blue,
      //   shape: RoundedRectangleBorder(
      //     borderRadius: BorderRadius.circular(30),
      //   ),
      // ),
    );
  }
}
