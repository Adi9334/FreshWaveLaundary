import 'package:flutter/material.dart';
import 'package:laundry_application/Components/Row_itemCustom.dart';
import 'package:laundry_application/Models/orderlist_model.dart';
import 'package:laundry_application/api_services/global.dart';
import 'package:laundry_application/ui_helper/util.dart';

class view_oreder_details_screen extends StatefulWidget {
  List<orderlist_model>? orders;

  view_oreder_details_screen({required this.orders});

  @override
  State<view_oreder_details_screen> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<view_oreder_details_screen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "Order Details",
            style: TextStyle(color: Colors.white),
          ),
          // backgroundColor: Colors.blue,
        ),
        backgroundColor: Colors.grey[300],
        body: SingleChildScrollView(
          child: Container(
            child: Column(
              children: [
                Container(
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Order Summary', style: heading()),
                        Text(
                            'Arrived at ${widget.orders![0].order_delivery_slot}'),
                        InkWell(
                            onTap: () {},
                            child: Row(
                              children: [
                                Text('Download Invoice',
                                    style: TextStyle(
                                        color: Colors.green,
                                        fontWeight: FontWeight.bold)),
                                Icon(
                                    color: Colors.green,
                                    size: 18,
                                    Icons.file_download),
                              ],
                            )),
                        Text(
                            "${widget.orders![0].item!.length} items in this order"),
                        ListView.separated(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: widget.orders![0].item!.length,
                          itemBuilder: (context, index) {
                            return ListTile(
                              leading: Container(
                                  padding: EdgeInsets.symmetric(vertical: 8),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          width: 0.5,
                                          color: Colors.grey.shade500),
                                      borderRadius: BorderRadius.circular(10)),
                                  height: 100,
                                  width: 75,
                                  child: Image.network(
                                      "${APIservice.address}${
                                    widget
                                      .orders![0].item![index].itemImage
                                      .toString()}")),
                              title: Text(widget
                                  .orders![0].item![index].itemName
                                  .toString()),
                              subtitle: Text(widget
                                  .orders![0].item![index].itemQuantity
                                  .toString()),
                              trailing: Text(
                                '₹ ${widget.orders![0].item![index].itemAmount}',
                                style: TextStyle(fontSize: 15),
                              ),
                            );
                          },
                          separatorBuilder: (context, index) {
                            return Divider(color: Colors.grey[400]);
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  padding: EdgeInsets.all(10),
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Bill Details",
                        style: heading().copyWith(fontSize: 20),
                      ),
                      Divider(color: Colors.grey[400]),
                      Column(children: [
                        Row_itemCustom(
                            name: "MRP",
                            value: widget.orders![0].order_mrp.toString()),
                        Row_itemCustom(
                            name: "Promocode",
                            value:
                                widget.orders![0].order_promocode.toString()),
                        Row_itemCustom(
                          name: "Discount",
                          value: widget.orders![0].order_discount.toString(),
                          Color: TextStyle(
                              color: secondary(), fontWeight: FontWeight.bold),
                        ),
                        Row_itemCustom(
                            name: "Total",
                            value: widget.orders![0].order_total_afterdis
                                .toString()),
                        Row_itemCustom(
                            name: "Tax",
                            value: widget.orders![0].order_tax.toString()),
                        Row_itemCustom(
                            name: "Handling Charges",
                            value: widget.orders![0].order_handling_charges
                                .toString()),
                        Row_itemCustom(
                            name: "Delivery Charges",
                            value: widget.orders![0].order_delivery_charges
                                .toString()),
                      ]),
                      Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Bill Total",
                              style: heading().copyWith(fontSize: 15),
                            ),
                            Text(
                              widget.orders![0].order_total_price.toString(),
                              style: heading().copyWith(fontSize: 15),
                            )
                          ])
                    ],
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                    padding: EdgeInsets.all(10),
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Order Details",
                          style: heading().copyWith(fontSize: 20),
                        ),
                        Divider(color: Colors.grey[400]),
                        Row_itemCustom(
                            name: "Order ID",
                            value: widget.orders![0].order_id.toString()),
                        Row_itemCustom(
                            name: "Payment Mode",
                            value: widget.orders![0].order_payment_mode),
                        Row_itemCustom(
                            name: "Delivery Type",
                            value: widget.orders![0].order_delivery_type),
                        Row_itemCustom(
                            name: "Delivered at",
                            value: widget.orders![0].order_delivered_at
                                .toString()),
                      ],
                    )),
                SizedBox(
                  height: 10,
                ),
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(10),
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Need help with your order?",
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(height: 10),
                      Divider(color: Colors.grey[400], thickness: 1),
                      SizedBox(height: 10),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          backgroundColor: Colors.blueAccent,
                          padding: EdgeInsets.symmetric(vertical: 15),
                        ),
                        onPressed: () {
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(builder: (context) => ChatScreen()),
                          // );
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.chat_bubble, color: Colors.white),
                            SizedBox(width: 10),
                            Text(
                              "Chat with us",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
