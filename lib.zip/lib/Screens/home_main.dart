import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:laundry_application/Components/CurvedAppBarClipper.dart';
import 'package:laundry_application/Components/CurvedBorderPainter.dart';
import 'package:laundry_application/Screens/Home_screen.dart';
import 'package:laundry_application/Screens/Myorders_screen.dart';
import 'package:laundry_application/Screens/NotificationScreen.dart';
import 'package:laundry_application/Screens/Profile_screen.dart';
import 'package:laundry_application/ui_helper/util.dart';

class home_main extends StatefulWidget {
  home_main({super.key});

  @override
  State<home_main> createState() => _home_mainState();
}

class _home_mainState extends State<home_main> {
  int _currentIndex = 0;

  List<Widget> _screens = [Home_screen(), Myorder_screen(), Profile_screen()];
  List<String> _appbarTitles = ['Laundry APP', 'My Orders', 'Profile'];

  @override
  void initState() {
    super.initState();
    // Add callback to handle system back button press
    WidgetsBinding.instance?.addPostFrameCallback((_) {
      ModalRoute.of(context)?.addScopedWillPopCallback(_onBackPressed);
    });
  }

  Future<bool> _onBackPressed() async {
    if (_currentIndex == 0) {
      // If on the home screen (index 0), show exit confirmation dialog
      bool exitConfirmed = await showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Are you sure you want to exit?'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text('No'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(true);
                exit(0); // Exit the app
              },
              child: Text('Yes'),
            ),
          ],
        ),
      );
      return exitConfirmed ?? false; // Return the dialog result or false
    } else {
      // If not on the home screen, navigate back to the home screen
      setState(() {
        _currentIndex = 0;
      });
      return false; // Do not exit the app
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(255, 255, 255, 1),
      appBar:
          // PreferredSize(
          //     preferredSize: Size.fromHeight(90),
          //     child: ClipPath(
          //         clipper: CurvedAppBarClipper(),
          //         child:
          AppBar(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(10),
          ),
        ),
        //surfaceTintColor: Colors.transparent,
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            Expanded(
              child: Align(
                alignment: _currentIndex == 0
                    ? Alignment.centerLeft
                    : Alignment.center,
                child: Text(
                  _appbarTitles[_currentIndex],
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            _currentIndex == 0
                ? Row(
                    children: [
                      IconButton(
                        icon: Icon(
                          Icons.notifications_outlined,
                          color: Colors.white,
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => NotificationScreen()));
                        },
                      ),
                      IconButton(
                        icon: Icon(
                          Icons.shopping_cart,
                          color: Colors.white,
                        ),
                        onPressed: () {},
                      ),
                    ],
                  )
                : Text(''),
          ],
        ),
        //))
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
        child: Container(
          height: 60,
          child: BottomNavigationBar(
            unselectedItemColor: Colors.black,
            items: [
              BottomNavigationBarItem(
                icon: ImageIcon(
                  AssetImage('assets/images/home.png'),
                  size: 20,
                  color: _currentIndex == 0
                      ? Color.fromARGB(255, 15, 65, 150)
                      : Colors.black,
                ),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: ImageIcon(
                  AssetImage('assets/images/myorders1.png'),
                  size: 20,
                  color: _currentIndex == 1
                      ? Color.fromARGB(255, 15, 65, 150)
                      : Colors.black,
                ),
                label: 'My Orders',
              ),
              BottomNavigationBarItem(
                icon: ImageIcon(
                  AssetImage('assets/images/profile.png'),
                  size: 20,
                  color: _currentIndex == 2
                      ? Color.fromARGB(255, 15, 65, 150)
                      : Colors.black,
                ),
                label: 'Profile',
              ),
            ],
            currentIndex: _currentIndex,
            selectedItemColor: Color.fromARGB(255, 15, 65, 150),
            onTap: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
            selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
            backgroundColor: Color.fromARGB(255, 252, 252, 252),
            showSelectedLabels: true,
            showUnselectedLabels: false,
          ),
        ),
      ),
    );
  }
}
