import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:laundry_application/Components/Myorder_card.dart';
import 'package:laundry_application/Models/orderlist_model.dart';
import 'package:laundry_application/Screens/home_main.dart';
import 'package:laundry_application/api_services/order_api.dart';
import 'package:laundry_application/api_services/user_api.dart';
import 'package:laundry_application/providers/UserDataProvider.dart';
import 'package:provider/provider.dart';

class Myorder_screen extends StatefulWidget {
  const Myorder_screen({super.key});

  @override
  State<Myorder_screen> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<Myorder_screen> {
  // List<Map<String, dynamic>> orders = [
  //   {
  //     "name": "Wash and Fold",
  //     "order_id": "4567",
  //     "order_date": "12-3-2024",
  //     "order_status": true,
  //     "item": [
  //       {
  //         "item_name": "Shirt/Tshirt",
  //         "item_quantity": 2,
  //         "item_amount": 200,
  //       },
  //       {
  //         "item_name": "Pant",
  //         "item_quantity": 3,
  //         "item_amount": 500,
  //       },
  //       {
  //         "item_name": "Trouser",
  //         "item_quantity": 10,
  //         "item_amount": 900,
  //       }
  //     ],
  //     "amount": "400"
  //   },
  //   {
  //     "name": "Wash and Fold",
  //     "order_id": "4567",
  //     "order_date": "12-3-2024",
  //     "order_status": false,
  //     "item": [
  //       {
  //         "item_name": "Shirt/Tshirt",
  //         "item_quantity": 2,
  //         "item_amount": 200,
  //       },
  //     ],
  //     "amount": "100000"
  //   }
  // ];
  List<orderlist_model> orderDataList = [];

  @override
  void initState() {
    super.initState();
    fecthData(); // Call fecthData() here
  }

  Future<void> fecthData() async {
    //final userdata = Provider.of<UserDataProvider>(context, listen: false);
    final id = await user_api.fetchUserID();
    print(id);
    List<orderlist_model> orderData = await order_api.fetchorders(id);
    if (mounted) {
      setState(() {
        orderDataList = orderData;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: orderDataList.isEmpty
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color.fromARGB(
                              255, 171, 224, 255), // Light blue shade (top)
                          Colors.white, // White (bottom)
                        ],
                        stops: [0.3, 1.0],
                      ),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(255, 51, 217, 242)
                                      .withOpacity(0.5),
                                  spreadRadius: 3,
                                  blurRadius: 7,
                                  offset: Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Icon(
                              Icons.search, // Changed icon to search
                              size: 100,
                              color: const Color.fromARGB(255, 72, 185, 241),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            'No order has been placed yet.',
                            style: TextStyle(
                                fontSize: 20,
                                color: Color.fromARGB(255, 14, 14, 14),
                                fontWeight: FontWeight.bold), // Bold text
                          ),
                          SizedBox(height: 10),
                          Text(
                            "Looks like you haven't made your order yet.",
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) => home_main()));
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        // Rectangle button shape
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      backgroundColor: Color.fromARGB(
                          255, 84, 197, 253), // Darker button color
                      padding:
                          EdgeInsets.symmetric(horizontal: 80, vertical: 18),
                    ),
                    child: Text(
                      'Back To Menu',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
                  ),
                ),
              ],
            )
          : ListView.builder(
              itemCount: orderDataList.length,
              itemBuilder: (context, index) {
                return Myorder_card(
                  order: orderDataList[index],
                );
              },
            ),
    );
  }
}
