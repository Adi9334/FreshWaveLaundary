import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';
import 'package:laundry_application/Components/Time_Card.dart';
import 'package:laundry_application/Components/Date_Card.dart';
import 'package:laundry_application/Models/service_model.dart';
import 'package:laundry_application/Screens/myorder_summary_screen.dart';
import 'package:laundry_application/providers/timeprovider.dart';
import 'package:laundry_application/ui_helper/util.dart';
import 'package:provider/provider.dart';

class TimeSlotPicker extends StatefulWidget {
  final serviceID;
  TimeSlotPicker({
    Key? key,
    required this.serviceID,
  });

  @override
  State<TimeSlotPicker> createState() => _TimeSlotState();
}

class _TimeSlotState extends State<TimeSlotPicker> {
  @override
  Widget build(BuildContext context) {
    TimeSlotProvider dataProvider = Provider.of<TimeSlotProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "PickUp Slot",
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.all(8.0),
              child: Column(
                children: [
                  DatePicker(),
                  TimeSlotSelector(),
                  SizedBox(height: 20),
                ],
              ),
            ),
          ),
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(8.0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: secondary(),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                padding: EdgeInsets.symmetric(vertical: 16),
              ),
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => myorder_summary_screen(
                              serviceID: widget.serviceID,
                            )));
              },
              child: Text(
                'Proceed to Pay',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
