import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:laundry_application/api_services/global.dart';
import 'package:http/http.dart' as http;
import 'package:laundry_application/api_services/user_api.dart';

// class FeedbackPage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(
//           'Feedback',
//           style: TextStyle(fontWeight: FontWeight.bold),
//         ),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: FeedbackForm(),
//       ),
//     );
//   }
// }

class feedbackcustom extends StatefulWidget {
  feedbackcustom({super.key});
  @override
  _FeedbackFormState createState() => _FeedbackFormState();
}

class _FeedbackFormState extends State<feedbackcustom> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phonenumberController = TextEditingController();
  int _rating = 0;
  String _feedback = '';

  Future<void> _submitFeedback() async {
    try {
      final id = await user_api.fetchUserID();
      // Prepare feedback data
      final feedbackData = {
        'user_id': id,
        'user_name': _nameController.text,
        'user_phonenumber': _phonenumberController.text,
        'user_rating': _rating,
        'user_review': _feedback,
        'created_by': 'user',
        'is_active': 1
      };

      // Send POST request to save feedback
      final response = await http.post(
        Uri.parse('${APIservice.address}/UserReview/addreview'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(feedbackData),
      );

      if (response.statusCode == 200) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text("Feedback Submitted"),
              content: Text("Your feedback has been submitted successfully."),
              actions: <Widget>[
                TextButton(
                  child: Text("OK"),
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                    Navigator.pop(context, true); // Close the previous screen
                  },
                ),
              ],
            );
          },
        );
      } else {
        // Handle error
        print('Failed to submit feedback');
      }
    } catch (e) {
      // Handle error
      print('Error submitting feedback: $e');
    }
  }

  Widget _buildStar(int index) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _rating = index + 1; // Store 1-based rating for simplicity
        });
      },
      child: Icon(
        index < _rating ? Icons.star : Icons.star_border,
        color: Colors.amber,
        size: 40.0,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Leave your feedback',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 20.0),
                  TextField(
                    controller: _nameController,
                    decoration: InputDecoration(
                      labelText: 'Name (optional)',
                      prefixIcon: Icon(Icons.person),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 10.0),
                  TextField(
                    controller: _phonenumberController,
                    decoration: InputDecoration(
                      labelText: 'Phone Number (optional)',
                      prefixIcon: Icon(Icons.phone),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 20.0),
                  Text(
                    'Rate the app:',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: List.generate(5, (index) => _buildStar(index)),
                  ),
                  SizedBox(height: 20.0),
                  TextField(
                    onChanged: (value) {
                      setState(() {
                        _feedback = value;
                      });
                    },
                    maxLines: 4,
                    decoration: InputDecoration(
                      labelText: 'Feedback',
                      prefixIcon: Icon(Icons.feedback),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 20.0),
                ],
              ),
            ),
          ),
        ),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () {
              _submitFeedback();
            },
            style: ButtonStyle(
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius
                      .zero, // Set zero border radius for rectangular shape
                ),
              ),
              backgroundColor: MaterialStateProperty.all<Color>(
                  Color.fromARGB(255, 10, 132, 232)), // Set blue color
            ),
            child: Text(
              'Submit',
              style: TextStyle(
                color: Colors.white, // White text color
                fontWeight: FontWeight.bold, // Making text bold
                fontSize: 20, // Increasing text size
              ),
            ),
          ),
        ),
      ],
    );
  }
}
