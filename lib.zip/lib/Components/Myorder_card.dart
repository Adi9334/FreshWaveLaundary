import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:laundry_application/Models/orderlist_model.dart';
import 'package:laundry_application/Screens/ReviewOrderScreen.dart';
import 'package:laundry_application/Screens/view_oreder_details_screen.dart';
import 'package:laundry_application/ui_helper/util.dart';

class Myorder_card extends StatelessWidget {
  final orderlist_model order;

  Myorder_card({required this.order});

  @override
  Widget build(BuildContext context) {
    DateTime orderDate = DateTime.parse(order.order_date);
    return Card(
      elevation: 1,
      surfaceTintColor: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          margin: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        color: order.order_status == "delivered"
                            ? Colors.green
                            : Colors.red,
                        order.order_status == "delivered"
                            ? Icons.check_circle_rounded
                            : Icons.cancel_rounded,
                      ),
                      SizedBox(width: 10),
                      Text(
                        order.name,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: primary(),
                        ),
                      ),
                    ],
                  ),
                  Spacer(),
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => view_oreder_details_screen(
                            orders: [order],
                          ),
                        ),
                      );
                    },
                    icon: Icon(Icons.arrow_right_alt),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Order Id : ${order.order_id.toString()}',
                        style: TextStyle(color: basic2(), fontSize: 17),
                      ),
                      Text(
                        '${DateFormat('dd-MMM-yy').format(orderDate)} ',
                        style: TextStyle(color: basic2(), fontSize: 17),
                      ),
                    ],
                  ),
                  Text(
                    'Total Rs. ${order.order_total_price.toString()}',
                    style: TextStyle(color: basic2(), fontSize: 17),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Expanded(
                    flex: 1,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(),
                        backgroundColor: basic(),
                      ),
                      onPressed: () {},
                      child: Text(
                        'Support',
                        style: TextStyle(
                          color: primary(),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    flex: 1,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(),
                        backgroundColor: secondary(),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ReviewOrderScreen(
                                    orderId: order.order_id.toString(),
                                    deliveryDate: orderDate)));
                      },
                      child: Text(
                        'Review',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
