import 'package:flutter/material.dart';

class Row_itemCustom extends StatelessWidget {
  final name;
  final value;
  final Color;
  const Row_itemCustom({
    required this.name,
    required this.value,
    this.Color,
    Key? key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Text(
        name,
        style: Color,
      ),
      Spacer(),
      Text(value, style: Color),
    ]);
  }
}
