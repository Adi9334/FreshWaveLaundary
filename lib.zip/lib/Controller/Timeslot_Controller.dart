import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:laundry_application/Models/Timeslot.dart';
import 'package:laundry_application/api_services/global.dart';
import 'package:laundry_application/providers/Dateprovider.dart';
import 'package:provider/provider.dart';

class SlotController {
  
}
